
package modelo;

import servicio.CSVSerializable;
import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable{
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public String getEspecie() {
        return especie;
    }
    
    @Override
    public int compareTo(Animal a) {
        return Integer.compare(this.id, a.id);
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion;
    }
    
    public static Animal fromCSV(String animalCSV) {
        //meter validaciones
        if (animalCSV.endsWith("\n")) {
            animalCSV = animalCSV.substring(0, animalCSV.length() - 1);
        }
        String[] data = animalCSV.split(",");
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    String especie = data[2];
                    TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
                   return new Animal(id, nombre, especie, alimentacion);
            }
  
}