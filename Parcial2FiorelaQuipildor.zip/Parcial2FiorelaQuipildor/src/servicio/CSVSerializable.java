
package servicio;

@FunctionalInterface
public interface CSVSerializable<T> {
    String toCSV();
}
