
package servicio;

public interface CSVSerializable<T> {

    String toCSV();
}
